from newsapp import db

class User(db.Model):
	id = db.Column(db.Integer, primary_key=True)
	username = db.Column(db.String(64), index=True, unique=True)
	email = db.Column(db.String(120), index=True, unique=True)
	password_hash = db.Column(db.String(128))
	discussions = db.relationship('Discussion', backref='author')
	invitations = db.relationship('Invitation',backref='author')
	profile = db.relationship('Profile',backref='user')

	def __repr__(self):
		return '<User {}>'.format(self.username)


class Discussion(db.Model):
	id = db.Column(db.Integer, primary_key=True, autoincrement=True)
	headline = db.Column(db.String(140), index=True)
	category = db.Column(db.String(10), index=True)
	kind = db.Column(db.String(10),index=True)
	body = db.Column(db.String(1500))
	reporter_id = db.Column(db.Integer, db.ForeignKey('user.id'))

	def __repr__(self):
		return '<Discussion made by {}>'.format(self.reporter_id)


class Invitation(db.Model):
	id = db.Column(db.Integer, primary_key=True)
	date = db.Column(db.Date, index=True)
	phone = db.Column(db.String)
	startTime = db.Column(db.Time)
	endTime = db.Column(db.Time)
	covers = db.Column(db.Integer)
	venue = db.Column(db.String(50))
	headline = db.Column(db.String(140), index=True)
	category = db.Column(db.String(10), index=True)
	body = db.Column(db.String(1500))
	reporter_id = db.Column(db.Integer, db.ForeignKey('user.id'))

	def __repr__(self):
		return '<Invitation made on {} by {}>'.format(str(self.date)[0:10],self.reporter_id)


class Profile(db.Model):
	id = db.Column(db.Integer, primary_key=True,autoincrement=True)
	name=db.Column(db.String(30))
	dob = db.Column(db.Date)
	gender = db.Column(db.String(10),index=True)
	description = db.Column(db.String(500))
	portrait = db.Column(db.String(50))
	user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

	def __repr__(self):
		return '<Profile by {}>'.format(self.user_id)


class Post(db.Model):
	id = db.Column(db.Integer, primary_key=True, autoincrement=True)
	discussion_id = db.Column(db.Integer, db.ForeignKey('discussion.id'))
	poster_id = db.Column(db.Integer, db.ForeignKey('user.id'))
	content = db.Column(db.String(500))

	def __repr__(self):
		return '<Post about {}>'.format(self.content)


class Join(db.Model):
	id = db.Column(db.Integer, primary_key=True, autoincrement=True)
	invitation_id = db.Column(db.Integer, db.ForeignKey('invitation.id'))
	user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
	phone = db.Column(db.String(50))
	body = db.Column(db.String(500))

	def __repr__(self):
		return '<Post about {}>'.format(self.content)


class Like(db.Model):
	id = db.Column(db.Integer, primary_key=True, autoincrement=True)
	user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
	post_id=db.Column(db.Integer,db.ForeignKey('post.id'),default=-1)
	discussion_id=db.Column(db.Integer,db.ForeignKey("discussion.id"),default=-1)

	def __repr__(self):
		return '<Like by {} for dis {} and post{}>'.format(self.user_id,self.discussion_id,self.post_id)


class Dislike(db.Model):
	id = db.Column(db.Integer, primary_key=True, autoincrement=True)
	user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
	post_id=db.Column(db.Integer,db.ForeignKey('post.id'),default=-1)
	discussion_id=db.Column(db.Integer,db.ForeignKey("discussion.id"),default=-1)

	def __repr__(self):
		return '<Dislike by {}>'.format(self.user_id)


class Reply(db.Model):
	id = db.Column(db.Integer, primary_key=True, autoincrement=True)
	discussion_id=db.Column(db.Integer,db.ForeignKey("discussion.id"),default=-1)
	post_id = db.Column(db.Integer, db.ForeignKey('post.id'))
	replier_id = db.Column(db.Integer, db.ForeignKey('user.id'))
	content= db.Column(db.String(500))

	def __repr__(self):
		return '<Reply about {}>'.format(self.content)
