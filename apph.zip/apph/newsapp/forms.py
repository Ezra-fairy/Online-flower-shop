from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, RadioField, DateField, SubmitField,TimeField,IntegerField,TextAreaField,SelectMultipleField,FileField
from wtforms.validators import DataRequired, Length, Regexp,Email
from flask_wtf.file import FileAllowed,FileRequired

class LoginForm(FlaskForm):
	username = StringField(
		label='Username',
		validators=[DataRequired("Please enter your username")],
	)
	password = PasswordField(
		label='Password',
		validators=[DataRequired("Please enter your password")]
	)
	submit = SubmitField('Login')


class SignupForm(FlaskForm):
	username = StringField(
		label='Username',
		validators=[DataRequired("Enter a username!"),
					Length(min=4, max=10,message="Length should be 4-10")]
	)
	email = StringField(
		label='Email',
		validators=[DataRequired("Enter an Email!")]
	)
	password = PasswordField(
		label='Password',
		validators=[DataRequired("Enter a password!"),
					Length(min=6, max=20,message="Length should be 6-20"),
					# 查下这个啥意思？
					Regexp("^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,20}$",message="Should have a digit and a letter")]
	)
	password2 = PasswordField(
		label='Repeat Password',
		validators=[DataRequired("Double check your password")]
	)
	submit = SubmitField('Register')


class PostInvitation(FlaskForm):
	headline = StringField(
		label='Headline *',
		validators=[DataRequired()]
	)
	date = DateField(
		label="Date * (Format: YYYY-MM-DD)",
		validators=[DataRequired()]
	)
	startTime = TimeField(
		label="Start Time * (Format: hh:mm)",
		validators=[DataRequired()]
	)
	endTime = TimeField(
		label="End Time * (Format: hh:mm)",
		validators=[DataRequired()]
	)
	covers = IntegerField(
		label="Covers",
		validators=[]
	)
	phone = StringField(
		label='Phone number to contact',
		validators=[DataRequired('Need a way to contact you')]
	)
	venue = StringField(
		label="Venue"
	)
	category = RadioField(
		label="Category *",
		validators=[DataRequired()],
		choices=[
			('0','Basketball'),
			('1','Soccer'),
			('2','Badminton'),
			('3','Table Tennis'),
			('4','Tennis'),
			('5','Running'),
		]
	)
	body = StringField(
		label='Introduction *',
		validators=[DataRequired()])
	submit = SubmitField('Send Invitation')


class PostDiscussion(FlaskForm):
	headline = StringField(
		label='Headline *',
		validators=[DataRequired()]
	)
	category = RadioField(
		label="Category *",
		validators=[DataRequired()],
		choices=[
			('0', 'Basketball'),
			('1', 'Soccer'),
			('2', 'Badminton'),
			('3', 'Table Tennis'),
			('4', 'Tennis'),
			('5', 'Running'),
		]
	)
	kind = RadioField(
		label="Kind *",
		validators=[DataRequired()],
		choices=[
			('0', 'Sports Match Discussion'),
			('1', 'Experience Sharing')
		]
	)
	body = TextAreaField(
		label='Introduction *',
		validators=[DataRequired()]
	)
	submit = SubmitField('Send Discussion')


class ProfileForm(FlaskForm):
	name=StringField(
		label="Full Name",
		validators=[
			DataRequired('Enter your full name please')
		]
	)
	dob = DateField(
		label="Date of Birth",
		validators=[
			DataRequired('Enter your birthday please')
		]
	)
	gender = RadioField(
		label="Gender",
		choices=[
			("0","Male"),
			("1","Female")
		],
		validators=[DataRequired("Choose your gender please")]
	)
	description=TextAreaField(
		label="Describe yourself",
		validators = [DataRequired("Just make more friends, enter something")]
	)
	portrait = FileField(
		label='Upload your portrait',
		validators=[
			FileRequired("Upload one please"),
			FileAllowed(['jpg'], "Must be a .jpg file")
		]
	)
	submit=SubmitField("Save")


class PostForm(FlaskForm):
	body=TextAreaField(validators=[DataRequired()])
	postSubmit = SubmitField("Post")


class CommentForm(FlaskForm):
	post_id = IntegerField()
	body = TextAreaField(validators=[DataRequired()])
	commentSubmit=SubmitField('Comment')


class JoinForm(FlaskForm):
	invitation_id = IntegerField()
	user_id = IntegerField()
	phone = StringField(
		label='Enter your phone number to contact',
		validators=[DataRequired('Need something to keep in touch')]
	)
	body=TextAreaField(
		label="Describe yourself a little bit"
	)
	joinSubmit = SubmitField("Submit and Join")