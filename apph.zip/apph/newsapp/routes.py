import os

from flask import render_template, flash, redirect, url_for, session, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from newsapp import app, db, Config
from newsapp.forms import LoginForm, PostInvitation, SignupForm, PostDiscussion, ProfileForm, PostForm, CommentForm, \
    JoinForm
from newsapp.models import User, Invitation, Discussion, Profile, Post, Like, Dislike, Reply, Join


@app.route('/')
@app.route('/index')
def index():
    return render_template('index.html', title='Home')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter(User.username == form.username.data).first()
        if user is None:
            flash("Please Register or Retry With a Valid Username")
            return redirect(url_for('login'))
        if not check_password_hash(user.password_hash, form.password.data):
            flash('Wrong Password')
            return redirect(url_for('login'))
        flash('Login Successfully')
        session['USERNAME'] = user.username
        return redirect('choice')
    return render_template('login.html', title='Log in', form=form)


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    form = SignupForm()
    if form.validate_on_submit():
        if form.password.data != form.password2.data:
            flash('Passwords do not match!')
            return redirect(url_for('signup'))
        passw_hash = generate_password_hash(form.password.data)
        user = User(username=form.username.data, email=form.email.data, password_hash=passw_hash)
        db.session.add(user)
        db.session.commit()
        session["USERNAME"] = user.username
        return redirect('choice')
    return render_template('signup.html', title='Register a new user', form=form)


@app.route('/postinvitation', methods=['GET', 'POST'])
def postInvitation():
    form = PostInvitation()
    if session['USERNAME'] is None:
        return redirect(url_for('signup'))
    if form.validate_on_submit():
        username = session['USERNAME']
        user = User.query.filter(User.username == username).first()
        print(form.category.data)
        invitation = Invitation(date=form.date.data, startTime=form.startTime.data, endTime=form.endTime.data,
                                covers=form.covers.data, venue=form.venue.data, headline=form.headline.data,
                                category=form.category.data, body=form.body.data, reporter_id=user.id,
                                phone=form.phone.data)
        db.session.add(invitation)
        db.session.commit()
        return redirect('choice')
    return render_template('invitation.html', form=form)


@app.route('/postdiscussion', methods=['GET', 'POST'])
def postDiscussion():
    form = PostDiscussion()
    if session['USERNAME'] is None:
        return redirect(url_for('signup'))
    if form.validate_on_submit():
        username = session['USERNAME']
        user = User.query.filter(User.username == username).first()
        print(form.category.data)
        discussion = Discussion(headline=form.headline.data, category=form.category.data,
                                kind=form.kind.data, body=form.body.data, reporter_id=user.id)
        db.session.add(discussion)
        db.session.commit()
        return redirect('choice')
    return render_template('discussion.html', form=form)


@app.route('/choice')
def choice():
    if not session.get("USERNAME") is None:
        user_in_db = User.query.filter(User.username == session.get("USERNAME")).first()
        basketballs = Discussion.query.filter(Discussion.category == '0').limit(3).all()
        soccers = Discussion.query.filter(Discussion.category == '1').limit(3).all()
        badmintons = Discussion.query.filter(Discussion.category == '2').limit(3).all()
        tables = Discussion.query.filter(Discussion.category == '3').limit(3).all()
        tenniss = Discussion.query.filter(Discussion.category == '4').limit(3).all()
        runnings = Discussion.query.filter(Discussion.category == '5').limit(3).all()
        basketballsI = Invitation.query.filter(Invitation.category == '0').limit(3).all()
        soccersI = Invitation.query.filter(Invitation.category == '1').limit(3).all()
        badmintonsI = Invitation.query.filter(Invitation.category == '2').limit(3).all()
        tablesI = Invitation.query.filter(Invitation.category == '3').limit(3).all()
        tennissI = Invitation.query.filter(Invitation.category == '4').limit(3).all()
        runningsI = Invitation.query.filter(Invitation.category == '5').limit(3).all()
        return render_template('choice.html', user=user_in_db, basketballs=basketballs, soccers=soccers,
                               badmintons=badmintons, tables=tables, tenniss=tenniss, runnings=runnings,
                               basketballsI=basketballsI, soccersI=soccersI,
                               badmintonsI=badmintonsI, tablesI=tablesI, tennissI=tennissI, runningsI=runningsI, )
    else:
        flash("User needs to either login or signup first")
        return redirect(url_for('login'))


@app.route('/logout')
def logout():
    if session['USERNAME'] is None:
        return redirect(url_for('signup'))
    session.pop("USERNAME", None)
    return redirect(url_for('index'))


@app.route('/info')
def info():
    if not session.get("USERNAME") is None:
        user_in_db = User.query.filter(User.username == session.get("USERNAME")).first()
        stored_profile = Profile.query.filter(Profile.user == user_in_db).first()
        my_discussion = Discussion.query.filter(Discussion.author == user_in_db).all()
        my_invitation = Invitation.query.filter(Invitation.author == user_in_db).all()
        liked = Like.query.filter(Like.user_id == user_in_db.id).all()
        liked_discussion = []
        liked_post = []
        for ld in liked:
            if ld.post_id == '':
                liked_discussion.append(Discussion.query.filter(Discussion.id == ld.discussion_id).first())
            else:
                liked_post.append(Post.query.filter(Post.id == ld.post_id).first())

        join = Join.query.filter(Join.user_id == user_in_db.id).all()
        joined = []
        for jd in join:
            joined.append(Invitation.query.filter(Invitation.id == jd.invitation_id).first())
        if stored_profile:
            return render_template('profile.html', profile=stored_profile, user=user_in_db,
                                   my_invitation=my_invitation, my_discussion=my_discussion,
                                   liked_post=liked_post, liked_discussion=liked_discussion, joined=joined)
        else:
            return redirect(url_for('edit'))
    else:
        flash("User needs to either login or signup first")
        return redirect(url_for('login'))


@app.route('/edit', methods=['GET', 'POST'])
def edit():
    form = ProfileForm()
    if session['USERNAME'] is None:
        return redirect(url_for('signup'))
    if form.validate_on_submit():
        pc_dir = Config.PC_UPLOAD_DIR
        file_obj = form.portrait.data
        pc_filename = form.name.data + '_PC.jpg'
        file_obj.save(os.path.join(pc_dir, pc_filename))
        username = session['USERNAME']
        user = User.query.filter(User.username == username).first()
        stored_profile = Profile.query.filter(Profile.user == user).first()
        if not stored_profile:
            profile = Profile(name=form.name.data, dob=form.dob.data, gender=form.gender.data,
                              description=form.description.data, portrait=pc_filename, user_id=user.id)
            db.session.add(profile)
        else:
            stored_profile.name = form.name.data
            stored_profile.dob = form.dob.data
            stored_profile.gender = form.gender.data
            stored_profile.description = form.description.data
            stored_profile.portrait = pc_filename
        db.session.commit()
        return redirect(url_for('info'))
    return render_template('edit.html', form=form)

@app.route('/discussiondetail/<id>', methods=['GET', 'POST'])
def discussionDetail(id):
    if session['USERNAME'] is None:
        return redirect(url_for('signup'))
    user = User.query.filter(User.username == session['USERNAME']).first()
    print(user)
    postForm = PostForm()
    commentForm = CommentForm()
    if postForm.postSubmit.data and postForm.validate():
        post = Post(discussion_id=id, poster_id=user.id, content=postForm.body.data)
        db.session.add(post)
        db.session.commit()
    elif commentForm.commentSubmit.data and commentForm.validate():
        print(commentForm.post_id.data)
        reply = Reply(discussion_id=id, post_id=commentForm.post_id.data, replier_id=user.id,
                      content=commentForm.body.data)
        db.session.add(reply)
        db.session.commit()
    discussion = Discussion.query.filter(Discussion.id == id).first()
    profile = Profile.query.filter(Profile.user_id == discussion.author.id).first()
    if not profile:
        portrait = 'default.jfif'
    else:
        portrait = profile.portrait
    all = []
    comments = []
    number = []
    posts = Post.query.filter(Post.discussion_id == id).all()
    for p in posts:
        thatUser = User.query.filter(User.id == p.poster_id).first()
        comment = Reply.query.filter(Reply.post_id == p.id).all()
        number.append(CommentNumber(post_id=p.id,number=len(comment)))
        for c in comment:
            u = User.query.filter(User.id == c.replier_id).first()
            comments.append(OneComment(username=u.username, post_id=p.id, body=c.content))
        authorProfile = Profile.query.filter(Profile.user_id == p.poster_id).first()
        if authorProfile:
            one = OnePost(thatUser.username, authorProfile.portrait, p.content, p.id)
        else:
            one = OnePost(thatUser.username, 'default.jfif', p.content, p.id)
        all.append(one)
    all_like = Like.query.filter(Like.discussion_id == id).filter(Like.post_id == '').all()
    all_likes = len(all_like)
    all_dislike = Dislike.query.filter(Dislike.discussion_id == id).filter(Dislike.post_id == '').all()
    all_dislikes = len(all_dislike)
    print(user)
    return render_template('discussionDetail.html', discussion=discussion, portrait=portrait,
                           user_id=user.id,
                           postForm=postForm, all=all, all_likes=all_likes, all_dislikes=all_dislikes,
                           commentForm=commentForm, comments=comments,number=number)


@app.route('/invitationdetail/<id>', methods=['GET', 'POST'])
def invitationDetail(id):
    if session['USERNAME'] is None:
        return redirect(url_for('signup'))
    user = User.query.filter(User.username == session['USERNAME']).first()
    joinForm = JoinForm()
    invitation = Invitation.query.filter(Invitation.id == id).first()
    profile = Profile.query.filter(Profile.user_id == invitation.author.id).first()
    if not profile:
        portrait = 'default.jfif'
    else:
        portrait = profile.portrait
    if joinForm.validate_on_submit():
        print(joinForm.user_id.data)
        print(joinForm.invitation_id.data)
        join_in_db = Join.query.filter(Join.invitation_id == joinForm.invitation_id.data).filter(Join.user_id == joinForm.user_id.data).first()
        if join_in_db:
            flash('You have already joined before!')
        else:
            join = Join(invitation_id=joinForm.invitation_id.data, user_id=user.id,
                        phone=joinForm.phone.data, body=joinForm.body.data)
            db.session.add(join)
            db.session.commit()
            flash('Join successfully!')

    users_joined = Join.query.filter(Join.invitation_id == id).all()
    all = []
    for x in users_joined:
        user = User.query.filter(User.id == x.user_id).first()
        all.append(OneJoin(user.username, x.phone, x.body))
    number = len(all)
    return render_template('invitationDetail.html', invitation=invitation, profile=profile,
                           joinForm=joinForm, portrait=portrait, all=all, number=number)


@app.route('/checkusername', methods=['POST'])
def check_username():
    chosen_name = request.form['username']
    user_in_db = User.query.filter(User.username == chosen_name).first()
    if not user_in_db:
        return jsonify({'text': 'Username is available',
                        'returnvalue': 0})
    else:
        return jsonify({'text': 'Username is already taken',
                        'returnvalue': 1})


@app.route('/checkemail', methods=['POST'])
def check_email():
    chosen_email = request.form['email']
    user_in_db = User.query.filter(User.email == chosen_email).first()
    if not user_in_db:
        return jsonify({'text': 'This Email is available',
                        'returnvalue': 0})
    else:
        return jsonify({'text': 'This Email is already taken',
                        'returnvalue': 1})


@app.route('/like', methods=['POST'])
def like():
    if session['USERNAME'] is None:
        return redirect(url_for('signup'))
    user_id = request.form['user_id']
    post_id = request.form['post_id']
    discussion_id = request.form['discussion_id']
    if post_id == '':
        print('i am in')
        like_in_db = Like.query.filter( Like.discussion_id == discussion_id).filter(Like.user_id == user_id).filter(Like.post_id == '').first()
    else:
        like_in_db = Like.query.filter(Like.post_id == post_id).filter(Like.user_id == user_id).filter(Like.discussion_id == discussion_id).first()
    if not like_in_db:
        newLike = Like(user_id=user_id, post_id=post_id, discussion_id=discussion_id)
        db.session.add(newLike)
        db.session.commit()
        return '0'
    else:
        print(like_in_db)
        db.session.delete(like_in_db)
        db.session.commit()
        return '1'


@app.route('/dislike', methods=['POST'])
def dislike():
    if session['USERNAME'] is None:
        return redirect(url_for('signup'))
    user_id = request.form['user_id']
    post_id = request.form['post_id']
    discussion_id = request.form['discussion_id']
    if post_id == '':
        dislike_in_db = Dislike.query.filter(
            Dislike.user_id == user_id).filter(Dislike.discussion_id == discussion_id).filter(Dislike.post_id == '').first()
    else:
        dislike_in_db = Dislike.query.filter(
            Dislike.post_id == post_id).filter(Dislike.user_id == user_id).filter(Dislike.discussion_id == discussion_id).first()
    if not dislike_in_db:
        newDislike = Dislike(user_id=user_id, post_id=post_id, discussion_id=discussion_id)
        db.session.add(newDislike)
        db.session.commit()
        return '0'
    else:
        db.session.delete(dislike_in_db)
        db.session.commit()
        return '1'


class OnePost:
    def __init__(self, username, portrait, content, id):
        self.username = username
        self.portrait = portrait
        self.content = content
        self.id = id

    def __repr__(self):
        return '<One post by {} of {}>'.format(self.username, self.content)


class OneJoin:
    def __init__(self, username, phone, body):
        self.username = username
        self.phone = phone
        self.body = body

    def __repr__(self):
        return '<One join by {} of {}>'.format(self.username, self.body)


class OneComment:
    def __init__(self, username, post_id, body):
        self.username = username
        self.post_id = post_id
        self.body = body


class CommentNumber:
    def __init__(self, post_id, number):
        self.post_id = post_id
        self.number = number
